"""Fixed-budget feasible projected searches, not a proof of closure on failure."""
from __future__ import annotations
import hashlib
import time
import numpy as np

SEED = 82024102027
TILES = (24,6,30,34,21,11,152,170,189,174,186,166)
STAGES = (('source','baseline'),('fresh','baseline'),('fresh','capacity'),('fresh','repair'))
QUANTUM = .001
GUARD = 1e-7


def initial_kicks(tile,stage,count=128,planes=128):
    """Fresh representations share raw starts; projection can differ by model."""
    if stage not in ('source','fresh') or count%2 or planes<1:
        raise ValueError('invalid fixed initialization domain')
    values=[]
    for index in range(count):
        generator=np.random.default_rng(np.random.SeedSequence([SEED,int(tile),0 if stage=='source' else 1,index]))
        value=generator.normal(size=planes)
        value*=.1/np.linalg.norm(value)
        if index in (0,count//2):
            value[:]=0
        values.append(value)
    return np.asarray(values),np.r_[np.ones(count//2),-np.ones(count//2)]


def tangent_reference(jacobian,direction,cutoff=1e-10):
    j,d=np.asarray(jacobian,dtype=float),np.asarray(direction,dtype=float)
    if j.ndim!=2 or d.shape!=(j.shape[1],) or not np.isfinite(j).all() or not np.isfinite(d).all():
        raise ValueError('finite Jacobian and matching direction required')
    u,s,v=np.linalg.svd(j,full_matrices=False)
    active=s>(s[0]*cutoff if len(s) else 0)
    projection=d-v[active].T@(v[active]@d)
    inverse=(v[active].T/s[active])@u[:,active].T
    return projection,inverse,int(active.sum())


def matching_bins(values,reference,scales,indices,quantum=QUANTUM,guard=GUARD):
    a,b,s=np.asarray(values),np.asarray(reference),np.asarray(scales)
    ix=np.asarray(indices,dtype=int)
    if a.shape!=b.shape or s.shape!=b.shape or np.any(s<=0) or not all(np.isfinite(v).all() for v in (a,b,s)):
        raise ValueError('finite feature/scale arrays required')
    delta=(a[ix]-b[ix])/s[ix]
    bins=np.rint(delta/quantum).astype(np.int64)
    margin=quantum/2-np.abs(delta)
    return dict(matched=bool(np.all(bins==0) and np.all(margin>=guard)),bins=bins,
        minimum_margin=float(np.min(margin)),maximum_scaled_change=float(np.max(np.abs(delta))))


def manifest(tile,stage,representation,count=128):
    if int(tile) not in TILES or (stage,representation) not in STAGES:
        raise ValueError('not a planned search case')
    position=TILES.index(int(tile))
    return dict(tile=int(tile),stage=stage,representation=representation,device=1 if position in (3,7,11) else 0,
        starts=count,seed=SEED,signs='first half maximize; second half minimize',
        seed_derivation='SeedSequence([seed,tile,source=0/fresh=1,start]); fresh representations share raw kicks')


def projected_batch(feature_function,target_function,ratio_function,kicks,signs,*,device,
                    max_iterations=1000,max_stalls=50,rank_cutoff=1e-10,step_norm=.1,
                    corrections=5,halvings=10,budget=None,checkpoint=None):
    """Search one small batch. Functions accept a single real angle vector.

    feature_function returns reference-centered robust-scale changes, not bins.
    target_function returns one scalar; ratio_function returns the two RMS ratios.
    Every accepted step is feasible and improving in its declared direction.
    """
    import torch
    kicks=np.asarray(kicks,dtype=float);signs=np.asarray(signs,dtype=float)
    if kicks.ndim!=2 or signs.shape!=(len(kicks),) or not np.isfinite(kicks).all() or not np.all(np.abs(signs)==1):
        raise ValueError('finite paired starts/signs required')
    started=time.perf_counter();batch,planes=kicks.shape
    tensor=lambda x:torch.as_tensor(x,dtype=torch.float64,device=device)
    vf=torch.func.vmap(feature_function)
    vt=torch.func.vmap(target_function)
    vr=torch.func.vmap(ratio_function)
    jac=torch.func.vmap(torch.func.jacrev(feature_function,chunk_size=4))
    grad=torch.func.vmap(torch.func.grad(target_function))
    # Leave an additional guard for independent CPU/direct-SHT replay rounding.
    half=QUANTUM/2-2*GUARD
    bound=np.pi/4
    def check_budget():
        if budget is not None:
            budget()
    def decomposed(j):
        if not bool(torch.isfinite(j).all().item()):
            raise FloatingPointError('nonfinite Jacobian at evaluated state')
        u,s,v=torch.linalg.svd(j,full_matrices=False)
        active=s>s[:,:1]*rank_cutoff
        reciprocal=torch.where(active,1/torch.clamp(s,min=torch.finfo(s.dtype).tiny),0.)
        return u,s,v,active,reciprocal
    def feasible(x):
        with torch.no_grad():
            value=vf(x);ratios=vr(x)
            finite=torch.isfinite(value).all(-1)&torch.isfinite(ratios).all(-1)
            valid=finite&(value.abs()<=half).all(-1)&(ratios<=.25).all(-1)&(x.abs()<=bound).all(-1)
        return valid,value,ratios
    def retract(proposal):
        x=proposal.detach().clamp(-bound,bound)
        for _ in range(corrections):
            check_budget()
            valid,values,ratios=feasible(x)
            if bool(valid.all().item()):
                break
            # Retraction only addresses local summary constraints. RMS violations
            # are rejected by the outer step-halving loop, never relaxed.
            finite=torch.isfinite(values).all(-1)&torch.isfinite(ratios).all(-1)
            if not bool(finite.all().item()):
                return x,valid
            j=jac(x)
            u,s,v,active,reciprocal=decomposed(j)
            residual=values-values.clamp(-half,half)
            adjustment=torch.einsum('bkp,bk->bp',v,
                torch.einsum('bdk,bd->bk',u,residual)*reciprocal)
            adjustment=torch.where(valid[:,None],torch.zeros_like(adjustment),adjustment)
            x=(x-adjustment).detach().clamp(-bound,bound)
        valid,_,_=feasible(x)
        return x,valid
    check_budget()
    zero=tensor(np.zeros_like(kicks))
    reference_y=vt(zero).detach()
    j0=jac(zero)
    _,_,v0,active0,_=decomposed(j0)
    raw=tensor(kicks)
    initial=raw-torch.einsum('bkp,bk->bp',v0,torch.einsum('bkp,bp->bk',v0,raw)*active0)
    x=zero.clone();initialized=torch.zeros(batch,dtype=torch.bool,device=device)
    for h in range(halvings):
        trial,valid=retract(initial*(.5**h))
        take=valid&~initialized
        x=torch.where(take[:,None],trial,x);initialized|=valid
        if bool(initialized.all().item()):
            break
    # Explicit zero fallback is recorded, not a replacement start or new seed.
    initial_values=x.detach().cpu().numpy()
    iterations=np.zeros(batch,dtype=np.int64);stalls=np.zeros(batch,dtype=np.int64)
    rejected=np.zeros(batch,dtype=np.int64);nonfinite=np.zeros(batch,dtype=np.int64)
    ranks=np.zeros(batch,dtype=np.int64);status=np.full(batch,'active',dtype='<U32')
    sign=tensor(signs)
    history=[]
    while np.any(status=='active'):
        check_budget()
        ids=np.flatnonzero(status=='active')
        index=torch.as_tensor(ids,device=device)
        current=x[index]
        j=jac(current)
        _,_,v,active,_=decomposed(j)
        g=grad(current)*sign[index,None]
        if not bool(torch.isfinite(g).all().item()):
            raise FloatingPointError('nonfinite objective gradient at accepted state')
        direction=g-torch.einsum('bkp,bk->bp',v,torch.einsum('bkp,bp->bk',v,g)*active)
        norm=torch.linalg.vector_norm(direction,dim=-1,keepdim=True)
        direction=direction/torch.clamp(norm,min=1e-30)
        old_y=vt(current).detach();chosen=current.clone()
        accepted=torch.zeros(len(ids),dtype=torch.bool,device=device)
        for h in range(halvings):
            trial,valid=retract(current+step_norm*(.5**h)*direction)
            with torch.no_grad():
                yy=vt(trial)
                finite=torch.isfinite(yy)
                improve=(yy-old_y)*sign[index]>1e-14
                take=valid&finite&improve&~accepted
                chosen=torch.where(take[:,None],trial,chosen)
                accepted|=take
                nonfinite[ids]+=~finite.cpu().numpy()
            if bool(accepted.all().item()):
                break
        x[index]=chosen.detach()
        accepted_np=accepted.cpu().numpy()
        iterations[ids]+=1
        stalls[ids]=np.where(accepted_np,0,stalls[ids]+1)
        rejected[ids]+=~accepted_np
        ranks[ids]=active.sum(-1).cpu().numpy()
        for index_np in ids:
            if iterations[index_np]>=max_iterations:
                status[index_np]='iteration_cap'
            elif stalls[index_np]>=max_stalls:
                status[index_np]='stalled'
        if len(history)==0 or int(iterations.max())//20>history[-1]['iteration']//20 or not np.any(status=='active'):
            with torch.no_grad():
                yy=vt(x).cpu().numpy();valid,values,ratios=feasible(x)
            if not bool(valid.all().item()):
                raise FloatingPointError('stored search state lost feasibility')
            record=dict(iteration=int(iterations.max()),targets=yy.tolist(),
                gaps=(yy-reference_y.cpu().numpy()).tolist(),ranks=ranks.tolist(),
                maximum_constraint=float(values.abs().max().item()),maximum_rms_ratio=float(ratios.max().item()),
                seconds=time.perf_counter()-started)
            history.append(record)
            if checkpoint is not None:
                checkpoint(dict(theta=x.detach().cpu().numpy(),iterations=iterations.copy(),stalls=stalls.copy(),status=status.copy(),history=history))
    with torch.no_grad():
        yy=vt(x).cpu().numpy();valid,values,ratios=feasible(x)
    return dict(theta=x.detach().cpu().numpy(),initial_theta=initial_values,raw_kicks=kicks,
        target=yy,reference_target=reference_y.cpu().numpy(),gap=yy-reference_y.cpu().numpy(),
        iterations=iterations,stalls=stalls,rejected=rejected,nonfinite_trials=nonfinite,
        rank=ranks,status=status,initial_retraction_succeeded=initialized.cpu().numpy(),
        feasible=valid.cpu().numpy(),history=history,seconds=time.perf_counter()-started)
