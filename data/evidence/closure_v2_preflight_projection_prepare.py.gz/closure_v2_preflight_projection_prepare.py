"""Fixed-fixture engineering preflight; never runs scientific optimization.

Outputs a compact actual-device numerical attestation and bounded native-batch
time/memory measurements on both GPUs. Existing evidence is never overwritten.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from cmbcst.closure_fibers import ClosureCUDA,features_numpy,ratios_numpy,projection_indices
from cmbcst.closure_gpu_v2 import ClosureBatchCUDA,RMS_RATIO_NAMES
from cmbcst.closure_jacobian import feature_jacobian
from cmbcst.closure_search_v2 import active_tangent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fixture_builder():
    test = ROOT/'tests/test_closure_gpu_v2.py'
    node = next(n for n in ast.parse(test.read_text()).body
                if isinstance(n,ast.FunctionDef) and n.name=='fixture_family')
    namespace = {'np':np}
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(test),'exec'),namespace)
    return namespace['fixture_family']


def scaled_error(actual,expected):
    return float(np.max(np.abs(np.asarray(actual)-expected)/(1+np.abs(expected)),initial=0.))


def benchmark(function,device,repeats):
    """Synchronized end-to-end wall timing, including Python/kernel dispatch."""
    with torch.no_grad():
        function()
        torch.cuda.synchronize(device)
        torch.cuda.reset_peak_memory_stats(device)
        samples = []
        for _ in range(repeats):
            torch.cuda.synchronize(device)
            started = time.perf_counter()
            event_start,event_end = torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
            event_start.record()
            output = function()
            event_end.record()
            torch.cuda.synchronize(device)
            samples.append(time.perf_counter()-started)
            del output
        return dict(wall_seconds=samples,median_seconds=float(np.median(samples)),
            final_cuda_event_milliseconds=event_start.elapsed_time(event_end),
            peak_allocated_bytes=torch.cuda.max_memory_allocated(device),
            peak_reserved_bytes=torch.cuda.max_memory_reserved(device))


def compact_checks(family,device):
    model = ClosureBatchCUDA(family,device)
    legacy = ClosureCUDA(family,device)
    angles = np.array([[.02,-.04,.01,.07],[-.03,.05,.06,-.02],[0.,0.,0.,0.]])
    x = torch.as_tensor(angles,device=device,dtype=torch.float64)
    features,jac = model.features_and_jacobian(x)
    actual = features.detach().cpu().numpy()
    analytic = jac.detach().cpu().numpy()
    automatic = torch.func.jacrev(legacy.features)(x[0]).detach().cpu().numpy()
    h = 1e-3
    finite = np.column_stack([(-features_numpy(family,angles[0]+2*np.eye(4)[p]*h)
        +8*features_numpy(family,angles[0]+np.eye(4)[p]*h)
        -8*features_numpy(family,angles[0]-np.eye(4)[p]*h)
        +features_numpy(family,angles[0]-2*np.eye(4)[p]*h))/(12*h) for p in range(4)])
    target,target_gradient = model.target_and_gradient(x)
    expected_target_gradient = torch.func.grad(lambda row:legacy.features(row,1)[22])(x[0])
    squared,rms_gradient = model.ratio_squared_and_gradient(x)
    expected_rms_gradient = torch.func.jacrev(lambda row:legacy.ratios(row).square())(x[0])
    errors = dict(features=scaled_error(actual,features_numpy(family,angles)),
        jacobian_autograd=scaled_error(analytic[0],automatic),
        jacobian_five_point=scaled_error(analytic[0],finite),
        target=scaled_error(target.detach().cpu().numpy(),features_numpy(family,angles,1)[:,22]),
        target_gradient=scaled_error(target_gradient[0].detach().cpu().numpy(),expected_target_gradient.detach().cpu().numpy()),
        ratio_squared=scaled_error(squared.detach().cpu().numpy(),ratios_numpy(family,angles)**2),
        rms_gradient=scaled_error(rms_gradient[0].detach().cpu().numpy(),expected_rms_gradient.detach().cpu().numpy()))
    for u in (1,2,3):
        errors[f'features_u{u}'] = scaled_error(model.features(x,u).detach().cpu().numpy(),features_numpy(family,angles,u))
    if not bool(torch.isfinite(rms_gradient).all()) or bool(torch.count_nonzero(rms_gradient[-1])):
        raise ValueError('zero-angle squared-RMS derivative must be finite and exactly zero')
    if max(errors.values())>1e-10:
        raise ValueError(f'numerical preflight failed: {errors}')
    return dict(angles=angles[0].tolist(),features=actual[0].tolist(),jacobian=analytic[0].tolist(),
        target=float(target[0]),target_gradient=target_gradient[0].detach().cpu().tolist(),
        ratio_squared=squared[0].detach().cpu().tolist(),
        rms_gradient=rms_gradient[0].detach().cpu().tolist(),errors=errors)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'data/evidence/closure_v2_preflight_final.json')
    parser.add_argument('--repeats',type=int,default=3)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError('preserve previous evidence; choose a new output path')
    if not 1 <= args.repeats <= 5:
        raise ValueError('bounded preflight requires one through five timing repetitions')
    if torch.cuda.device_count()<2:
        raise RuntimeError('both approved actual GPUs are required')
    sources = ('src/cmbcst/closure_gpu_v2.py','scripts/prepare_closure_fibers_v2.py',
        'tests/test_closure_gpu_v2.py','src/cmbcst/closure_fibers.py','src/cmbcst/closure_jacobian.py',
        'src/cmbcst/closure_search_v2.py')
    before_hashes = {name:sha(ROOT/name) for name in sources}
    fixture = fixture_builder()
    compact = fixture()
    stress = fixture(n=264,planes=128)
    real_path = ROOT/'data/work/closure_integration_preflight_v1/family_24.npz'
    manifest_path = real_path.with_suffix('.json')
    manifest = json.loads(manifest_path.read_text())
    if sha(real_path)!=manifest['family_sha256']:
        raise ValueError('actual fixed-angle operator cache failed manifest hash')
    with np.load(real_path,allow_pickle=False) as archive:
        real = {name:archive[name] for name in archive.files}
    record = dict(status='running',purpose='fixed-angle engineering accuracy and performance; no scientific search',
        ratio_names=RMS_RATIO_NAMES,seed=929173,source_sha256=before_hashes,
        python=sys.version,numpy=np.__version__,torch=str(torch.__version__),cuda=torch.version.cuda,
        cpu_threads=8,fixtures=dict(compact=dict(n=8,planes=4),performance=dict(n=264,planes=128),
            actual_tile_24=dict(n=66,planes=128,family_sha256=sha(real_path),
                manifest_sha256=sha(manifest_path),input_sha256=manifest['configuration']['source']['input_sha256'])),devices=[])
    torch.set_num_threads(8)
    for index in (0,1):
        device = f'cuda:{index}'
        with torch.cuda.device(index):
            free,total = torch.cuda.mem_get_info(index)
            if free<512*1024**2:
                raise RuntimeError('insufficient free GPU memory for bounded preflight')
            evidence = dict(device=device,name=torch.cuda.get_device_name(index),
                free_bytes_before=free,total_bytes=total,recommended_batch=128 if index==0 else 64,
                compact=compact_checks(compact,device),benchmarks=[])
            for fixture_name,family in (('actual_tile_24',real),('synthetic_n264',stress)):
                model = ClosureBatchCUDA(family,device)
                old_model = ClosureCUDA(family,device)
                for batch in (4,64,128):
                    angles = .015*np.sin((np.arange(batch)[:,None]+1)*(np.arange(128)[None,:]+.5))
                    x = torch.as_tensor(angles,device=device,dtype=torch.float64)
                    def bundle():
                        return (model.features_and_jacobian(x),model.target_and_gradient(x),
                                model.ratio_squared_and_gradient(x))
                    measured = benchmark(bundle,device,args.repeats)
                    measured.update(fixture=fixture_name,batch=batch,starts_per_second=batch/measured['median_seconds'])
                    actual = model.features(x[[0,-1]]).detach().cpu().numpy()
                    measured['feature_cpu_error'] = scaled_error(actual,features_numpy(family,angles[[0,-1]]))
                    if measured['feature_cpu_error']>1e-10:
                        raise ValueError('native batch feature precision failure')
                    if measured['peak_allocated_bytes']>.75*free:
                        raise MemoryError('preflight exceeded declared 75% free-memory envelope')
                    # A finite representative [B,48,128] Jacobian, normalized by
                    # fixed positive feature scales, for the solver's exact SVD.
                    scale = torch.as_tensor(np.maximum(.001,np.abs(features_numpy(family,np.zeros(128))))[projection_indices('repair')],device=device)
                    j = model.feature_jacobian(x,indices='repair')/scale[None,:,None]
                    if not bool(torch.isfinite(j).all()):
                        raise ValueError('nonfinite benchmark Jacobian')
                    measured['thin_svd'] = benchmark(lambda:torch.linalg.svd(j,full_matrices=False),device,args.repeats)
                    def projection_bundle():
                        feature,jac = model.features_and_jacobian(x,indices='repair')
                        value,gradient = model.target_and_gradient(x)
                        squared,rms_gradient = model.ratio_squared_and_gradient(x)
                        projected = active_tangent(jac/scale[None,:,None],gradient,x,
                            torch.sqrt(squared),rms_gradient)
                        return feature,value,squared,projected
                    measured['bundle_and_active_tangent'] = benchmark(projection_bundle,device,args.repeats)
                    measured['projection_scope'] = 'one full feature/gradient evaluation and actual active-set SVD projection; excludes restoration and backtracking'
                    if batch==(128 if index==0 else 64):
                        measured['exact_svd_backend'] = {
                            driver:benchmark(lambda:torch.linalg.svd(j,full_matrices=False,driver=driver),device,1)
                            for driver in ('gesvd','gesvdj')}
                    if batch==4:
                        measured['v1_native_batch_analytic_jacobian'] = benchmark(
                            lambda:feature_jacobian(old_model,x),device,args.repeats)
                    evidence['benchmarks'].append(measured)
                    print(json.dumps(dict(device=device,fixture=fixture_name,batch=batch,seconds=measured['median_seconds'],
                        svd_seconds=measured['thin_svd']['median_seconds'],
                        projection_seconds=measured['bundle_and_active_tangent']['median_seconds'],
                        starts_per_second=measured['starts_per_second'],peak_bytes=measured['peak_allocated_bytes'])),flush=True)
                del model,old_model,x,j
            record['devices'].append(evidence)
    if before_hashes!={name:sha(ROOT/name) for name in sources}:
        raise RuntimeError('source changed during preflight')
    record['status']='passed'
    record['source_unchanged']=True
    payload = json.dumps(record,indent=2,allow_nan=False)
    if len(payload.encode())>180*1024:
        raise ValueError('compact actual-device attestation exceeds sandbox input envelope')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x',encoding='utf-8') as stream:
        stream.write(payload+'\n')
    print(json.dumps(dict(status='passed',output=str(args.output),sha256=sha(args.output))))


if __name__=='__main__':
    main()
