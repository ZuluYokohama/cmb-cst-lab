import numpy as np
from solution import features_numpy, ratios_numpy, moments_with_derivatives, projection_indices, robust_scales, quantize
from solution import harmonic_layout,build_planes,apply_angles,invariants,tangent_reference,matching_bins,initial_kicks

GPU_ATTESTATION = {'seed': 929173, 'devices': [{'device': 'cuda:0', 'name': 'NVIDIA GeForce RTX 5070', 'features': [18.299722685024715, 12.423572548743259, 2.7206157768332617, 9.041131696858624, 6.320515920025362, 0.18043538381383972, -0.000542601393364704, 0.24874656716741703, 23.980764532074218, 14.386699209493663, 1.150546465508858, 10.1671391681464, 9.016592702637542, 0.061942976220244826, -0.14268575290724347, 0.2616854427940167, 18.34612003191868, 14.10351816177748, 1.2019819745063804, 8.71340053567723, 7.511418561170849, 0.07472434354757736, -0.2959290311709337, 0.25433133438667144, 21.948306450575625, 12.827070284040587, -1.04764822515729, 8.170020071075408, 9.217668296232699, -0.06243832395738564, -0.4777131880013382, 0.41005072425282685, 5.82978401095665, 2.2174612515033045, 0.4774310404671165, 1.9602629191628564, 1.5685178701328595, -0.2595013538823301, 2.424039065623226, 1.0346704572197338, 0.4498110724484385, 1.5148985050306623, 1.76476190363873, 0.5943915392596827, -6.3504341590570395, -6.554065898911469, -4.833464384945426, -4.676997539776845, 0.04482272124851601, 0.012999479044128844, -0.03494268005739853, 0.1285617146068471], 'ratios': [0.004551203555625844, 0.007663477587998875], 'jacobian': [[-0.3070844331704403, 0.04280997951690191, -0.16612077942641654, 0.4743123723816562], [0.12395214079574708, 0.016529374425462637, 0.035168749572607724, -0.17996308510338932], [-0.09156614618734671, 0.029669676971182286, -0.0654760149269044, 0.14717464363913346], [-0.09156614618734668, 0.02966967697118228, -0.06547601492690443, 0.14717464363913346], [0.0, 0.0, 0.0, 0.0], [-0.005458996670163608, 0.0016366515805304243, -0.0037788820705243658, 0.008729343818083563], [-0.012334539276027309, -0.0046646090398247, 0.02642226799182098, -0.014768426843508247], [0.0124873981319976, -0.004546319463396346, 0.012288565068427324, -0.014901305620530438], [-0.23164680170263577, 0.22142236544490718, -0.25099479420684107, 0.02449748570523697], [0.25556551820027285, -0.16107835964903874, 0.0080992055271949, -0.14352262846026342], [0.011959358248818563, 0.03017200289793421, -0.12144779433982306, -0.05951257137751323], [0.011959358248818549, 0.030172002897934248, -0.12144779433982306, -0.059512571377513215], [0.0, 0.0, 0.0, 0.0], [0.00039286353633309694, 0.001685193743298402, -0.006231763730418515, -0.0029266956500140474], [0.0017852463617589924, -0.0034187574066186204, -0.010194241928009079, -0.0015708000595660613], [0.0014947606846100552, 0.0009216126479193883, -0.010230240354405404, 0.006252308146584475], [-0.026202641996338, -0.09568705764823753, 0.35855719612458087, -0.08716475417277884], [0.38182623918529146, -0.2756440201638427, 0.14248996554760857, -0.48637144577450436], [0.17781179859447657, -0.18566553890603998, 0.25052358083609466, -0.2867680999736417], [0.1778117985944766, -0.18566553890604007, 0.2505235808360947, -0.28676809997364167], [0.0, 0.0, 0.0, 0.0], [0.010095985641943478, -0.010617294926805776, 0.014466768427047824, -0.01636170894594323], [-0.007825827945376652, -0.005717780140630502, 0.00015869313703706578, 0.008965202614042678], [0.027303255645959985, -0.009549758013683251, -0.007621530824522072, -0.009714306243570165], [0.13587429639537177, 0.5685140130885371, 0.0897972001993226, -0.07630942507381507], [0.38926224529758063, -0.22427190413800457, -0.08381111499914282, -0.38263665312802037], [0.262568270846476, 0.17212105447526635, 0.0029930426000898875, -0.22947303910091765], [0.2625682708464761, 0.17212105447526638, 0.0029930426000898875, -0.22947303910091763], [0.0, 0.0, 0.0, 0.0], [0.0167893631783632, 0.01052097410652569, 0.00010212445297951483, -0.01471608460276409], [0.009853047648492225, -0.030881067384675154, 0.004137254602845406, -0.0123392053983637], [0.00920093277166791, -0.0075095118213823414, 0.012474783432306357, -0.01952327898718105], [-0.07598535674174663, 0.0, 0.0, 0.0], [0.17227890532278395, 0.0, 0.0, 0.0], [0.048146774290518675, 0.0, 0.0, 0.0], [0.0, 0.15695680524645844, 0.0, 0.0], [0.0, -0.08077576665905441, 0.0, 0.0], [0.0, 0.03809051929370203, 0.0, 0.0], [0.0, 0.0, -0.049517200018337475, 0.0], [0.0, 0.0, -0.04998638510222169, 0.0], [0.0, 0.0, -0.04975179256027958, 0.0], [0.0, 0.0, 0.0, -0.07706820167421374], [0.0, 0.0, 0.0, -0.09346895962372277], [0.0, 0.0, 0.0, -0.08526858064896824], [0.04689236411713007, -5.393298302558934e-05, 0.06309520895098025, -0.09726350234072303], [0.0042684976433692325, -0.027255614888658828, 0.10685021623650873, 0.09627472995081414], [-0.06274424281506633, 0.049066840912677656, -0.14231792826729353, 0.21242406658703522], [-0.04070569660679272, -0.11579104482091147, -0.014371045508180955, 0.21347139031435788], [-0.010654795309814481, 0.0042128633342139185, 0.0007137447344568865, -0.0015943608866439735], [0.0018294577439231755, 0.0022439310916146983, 0.00034552126851489353, 0.004299567092866633], [-0.00014350411170401483, 0.00011108420211756073, 0.001275050057099184, 0.003728852190276367], [-0.0004264438138611099, -0.01897076615565782, -0.0044144387657507255, -0.0018197491322891975]], 'errors': {'features': 6.302339632288665e-16, 'ratios': 8.673617379884035e-19, 'jacobian_five_point': 4.499506685756421e-12, 'analytic_response': 7.137645971266811e-17}, 'nonclosed_control_theta': [0.0, 0.7853981633974483], 'identity_control_gap': [0.0, 0.0], 'solver_control_seconds': 1.9722488999999968}, {'device': 'cuda:1', 'name': 'NVIDIA GeForce GTX 1660 Ti', 'features': [18.299722685024715, 12.423572548743259, 2.7206157768332617, 9.041131696858624, 6.320515920025362, 0.18043538381383972, -0.000542601393364954, 0.24874656716741703, 23.980764532074218, 14.386699209493663, 1.1505464655088564, 10.1671391681464, 9.016592702637544, 0.06194297622024474, -0.14268575290724347, 0.2616854427940167, 18.34612003191868, 14.10351816177748, 1.2019819745063804, 8.71340053567723, 7.51141856117085, 0.07472434354757736, -0.2959290311709337, 0.25433133438667144, 21.948306450575625, 12.827070284040587, -1.04764822515729, 8.170020071075408, 9.217668296232699, -0.06243832395738564, -0.4777131880013383, 0.41005072425282685, 5.82978401095665, 2.2174612515033045, 0.4774310404671165, 1.9602629191628564, 1.5685178701328595, -0.2595013538823301, 2.424039065623226, 1.0346704572197338, 0.4498110724484385, 1.5148985050306623, 1.76476190363873, 0.5943915392596827, -6.3504341590570395, -6.554065898911469, -4.833464384945426, -4.676997539776845, 0.044822721248515975, 0.012999479044128844, -0.03494268005739853, 0.1285617146068468], 'ratios': [0.004551203555625843, 0.007663477587998875], 'jacobian': [[-0.3070844331704403, 0.04280997951690195, -0.16612077942641645, 0.4743123723816563], [0.12395214079574697, 0.01652937442546259, 0.03516874957260772, -0.17996308510338926], [-0.09156614618734671, 0.029669676971182272, -0.0654760149269044, 0.14717464363913346], [-0.09156614618734671, 0.029669676971182286, -0.06547601492690439, 0.14717464363913343], [0.0, 0.0, 0.0, 0.0], [-0.0054589966701636084, 0.0016366515805304235, -0.0037788820705243666, 0.008729343818083561], [-0.012334539276027312, -0.004664609039824698, 0.026422267991820975, -0.014768426843508249], [0.012487398131997597, -0.004546319463396346, 0.012288565068427324, -0.014901305620530438], [-0.23164680170263574, 0.2214223654449072, -0.25099479420684107, 0.024497485705237004], [0.2555655182002729, -0.16107835964903877, 0.008099205527194883, -0.14352262846026348], [0.011959358248818518, 0.03017200289793424, -0.12144779433982308, -0.059512571377513215], [0.011959358248818545, 0.03017200289793424, -0.12144779433982308, -0.059512571377513174], [0.0, 0.0, 0.0, 0.0], [0.00039286353633309813, 0.0016851937432984015, -0.006231763730418519, -0.0029266956500140456], [0.001785246361758989, -0.003418757406618613, -0.010194241928009082, -0.0015708000595660615], [0.0014947606846100556, 0.0009216126479193876, -0.010230240354405404, 0.0062523081465844735], [-0.02620264199633793, -0.09568705764823746, 0.3585571961245808, -0.08716475417277889], [0.38182623918529146, -0.27564402016384243, 0.14248996554760854, -0.4863714457745044], [0.17781179859447666, -0.18566553890603996, 0.2505235808360948, -0.28676809997364155], [0.1778117985944767, -0.18566553890604, 0.2505235808360948, -0.2867680999736416], [0.0, 0.0, 0.0, 0.0], [0.010095985641943485, -0.010617294926805777, 0.014466768427047822, -0.016361708945943236], [-0.007825827945376647, -0.0057177801406305085, 0.0001586931370370672, 0.008965202614042682], [0.02730325564595996, -0.009549758013683247, -0.007621530824522069, -0.00971430624357016], [0.13587429639537182, 0.5685140130885373, 0.08979720019932266, -0.07630942507381493], [0.3892622452975805, -0.22427190413800469, -0.08381111499914283, -0.38263665312802053], [0.26256827084647616, 0.1721210544752663, 0.0029930426000899296, -0.22947303910091763], [0.2625682708464761, 0.17212105447526632, 0.0029930426000899226, -0.2294730391009176], [0.0, 0.0, 0.0, 0.0], [0.016789363178363197, 0.010520974106525697, 0.00010212445297951681, -0.014716084602764093], [0.00985304764849223, -0.03088106738467516, 0.004137254602845407, -0.012339205398363695], [0.009200932771667912, -0.00750951182138234, 0.012474783432306359, -0.019523278987181043], [-0.0759853567417466, 0.0, 0.0, 0.0], [0.17227890532278392, 0.0, 0.0, 0.0], [0.048146774290518675, 0.0, 0.0, 0.0], [0.0, 0.15695680524645844, 0.0, 0.0], [0.0, -0.08077576665905441, 0.0, 0.0], [0.0, 0.03809051929370203, 0.0, 0.0], [0.0, 0.0, -0.049517200018337475, 0.0], [0.0, 0.0, -0.04998638510222169, 0.0], [0.0, 0.0, -0.04975179256027958, 0.0], [0.0, 0.0, 0.0, -0.07706820167421374], [0.0, 0.0, 0.0, -0.09346895962372277], [0.0, 0.0, 0.0, -0.08526858064896824], [0.04689236411713008, -5.3932983025580666e-05, 0.06309520895098024, -0.09726350234072301], [0.004268497643369208, -0.027255614888658835, 0.1068502162365087, 0.09627472995081414], [-0.06274424281506631, 0.04906684091267764, -0.14231792826729353, 0.21242406658703508], [-0.04070569660679271, -0.11579104482091147, -0.01437104550818094, 0.21347139031435788], [-0.010654795309814485, 0.00421286333421392, 0.0007137447344568898, -0.0015943608866439848], [0.0018294577439231803, 0.002243931091614701, 0.0003455212685148953, 0.004299567092866633], [-0.00014350411170400398, 0.00011108420211755943, 0.0012750500570991837, 0.0037288521902763623], [-0.0004264438138610959, -0.01897076615565782, -0.004414438765750726, -0.0018197491322892003]], 'errors': {'features': 6.302339632288665e-16, 'ratios': 0.0, 'jacobian_five_point': 4.499443014332943e-12, 'analytic_response': 7.424056130804059e-17}, 'nonclosed_control_theta': [0.0, 0.7853981633974483], 'identity_control_gap': [0.0, 0.0], 'solver_control_seconds': 0.5803893000000002}]}


def fixture_family(planes=4):
    rng = np.random.default_rng(929173)
    n,m = 8,17*8
    rates = np.array([.04,.11,.23,.41,.67])
    components = rng.normal(size=(5,2,m))+1j*rng.normal(size=(5,2,m))
    times = np.arange(4)
    base = np.einsum('tk,ksm->tsm',np.exp(-times[:,None]*rates),components)
    derivative = np.einsum('tk,ksm->tsm',-rates*np.exp(-times[:,None]*rates),components)
    bands = np.stack([np.einsum('tk,ksn->tsn',np.exp(-times[:,None]*rates[np.arange(5)%4==band]),
        components[np.arange(5)%4==band,:,:n]) for band in range(4)],axis=2)
    p0 = np.exp(-2j*rng.uniform(-np.pi,np.pi,size=(4,4,n)))
    p1 = np.exp(-2j*rng.uniform(-np.pi,np.pi,size=(4,4,n)))
    valid = rng.uniform(size=(4,4,n))>.2
    return dict(base=base,base_derivative=derivative,base_band=bands,
        cos_basis=.1*(rng.normal(size=(planes,m))+1j*rng.normal(size=(planes,m))),
        sin_basis=.1*(rng.normal(size=(planes,m))+1j*rng.normal(size=(planes,m))),
        rates=np.linspace(.05,.5,planes),band_id=np.arange(planes)%4,
        phase0=p0,phase1=p1,valid=valid,
        reference_local_rms=float(np.sqrt(np.mean(np.abs(base[0].mean(axis=0)[:n])**2))),
        reference_global_rms=2.,global_weights=np.linspace(.01,.04,planes))


def covariance_oracle(a,b):
    x=np.column_stack([a.real,a.imag,b.real,b.imag])
    x-=x.mean(axis=0)
    c=x.T@x/len(x)
    va,vb=np.trace(c[:2,:2]),np.trace(c[2:,2:])
    re,im=c[0,2]+c[1,3],c[1,2]-c[0,3]
    fourth=np.mean(np.sum(x[:,:2]**2,axis=1)*np.sum(x[:,2:]**2,axis=1))
    return np.array([va,vb,re,(va+vb+2*re)/4,(va+vb-2*re)/4,re/np.sqrt(va*vb),
        (fourth-va*vb-2*np.sum(c[:2,2:]**2))/(va*vb),im/np.sqrt(va*vb)])


def test_analytic_moments_against_real_covariance_and_finite_difference():
    rng=np.random.default_rng(71844)
    a,b,da,db=rng.normal(size=(4,128))+1j*rng.normal(size=(4,128))
    value,derivative=moments_with_derivatives(a,b,da,db)
    assert np.max(np.abs(value-covariance_oracle(a,b)))<1e-12
    h=1e-3
    finite=(-covariance_oracle(a+2*h*da,b+2*h*db)+8*covariance_oracle(a+h*da,b+h*db)
            -8*covariance_oracle(a-h*da,b-h*db)+covariance_oracle(a-2*h*da,b-2*h*db))/(12*h)
    assert np.max(np.abs(finite-derivative)/(1+np.abs(derivative)))<1e-10


def test_time_derivatives_include_mean_centering():
    rng=np.random.default_rng(10483)
    a,b,da,db=rng.normal(size=(4,64))+1j*rng.normal(size=(4,64))
    stats,derivative=moments_with_derivatives(a,b,da,db)
    shifted,rate=moments_with_derivatives(a+13+2j,b-8j,da+7j,db-12)
    assert np.allclose(stats,shifted,atol=1e-12)
    assert np.allclose(derivative,rate,atol=1e-12)


def test_feature_layout_and_zero_plane_references():
    family=fixture_family(0)
    feature=features_numpy(family,np.zeros(0))
    assert feature.shape==(52,) and np.isfinite(feature).all()
    assert np.array_equal(ratios_numpy(family,np.zeros(0)),[0.,0.])
    n=family['valid'].shape[-1]
    values=family['base'][0]
    inc=values[:,n:].reshape(2,4,4,n)*family['phase1']-values[:,:n,None,None].transpose(0,2,3,1)*family['phase0']
    for lag in range(4):
        x=inc[:,lag][:,family['valid'][lag]]
        assert np.allclose(feature[lag*8:(lag+1)*8],covariance_oracle(x[0],x[1]),atol=1e-12)
    for band in range(4):
        a,b=family['base_band'][0,:,band]
        assert np.allclose(feature[32+band*3:35+band*3],[np.mean(np.abs(a)**2),np.mean(np.abs(b)**2),np.mean((a*b.conj()).real)],atol=1e-12)


def test_projection_quantization_and_scale_floors():
    assert np.array_equal(projection_indices('baseline'),np.arange(44))
    assert np.array_equal(projection_indices('capacity'),np.arange(48))
    assert np.array_equal(projection_indices('repair'),np.r_[np.arange(44),np.arange(48,52)])
    ref=np.arange(52,dtype=float)/10
    scale=robust_scales(np.stack([ref,ref,ref]))
    assert np.array_equal(scale,.001*np.maximum(1,np.abs(ref)))
    assert np.array_equal(quantize(ref,ref,scale),np.zeros(44,dtype=np.int64))
    assert np.array_equal(quantize(ref+.00049*scale,ref,scale),np.zeros(44,dtype=np.int64))
    assert np.array_equal(quantize(ref+.00051*scale,ref,scale),np.ones(44,dtype=np.int64))


def test_batched_numpy_and_ratios():
    family=fixture_family()
    theta=np.array([[.02,-.04,.01,.07],[-.03,.05,.06,-.02]])
    actual=features_numpy(family,theta,2)
    assert actual.shape==(2,52)
    assert np.allclose(actual,np.stack([features_numpy(family,row,2) for row in theta]),atol=1e-12)
    expected=np.sqrt(np.sum(2*(1-np.cos(theta))*family['global_weights'],axis=1))/family['reference_global_rms']
    assert np.allclose(ratios_numpy(family,theta)[:,1],expected,atol=1e-14)


def test_invalid_and_degenerate_inputs_rejected():
    family=fixture_family()
    for changed in ({**family,'rates':np.full(4,np.nan)}, {**family,'global_weights':-np.ones(4)},
                    {**family,'valid':np.zeros_like(family['valid'])}):
        try:
            features_numpy(changed,np.zeros(4))
        except ValueError:
            pass
        else:
            raise AssertionError('invalid family accepted')
    try:
        moments_with_derivatives(np.ones(8),np.ones(8),np.zeros(8),np.zeros(8))
    except ValueError:
        pass
    else:
        raise AssertionError('degenerate variance accepted')


def test_recorded_actual_gpu_features_and_jacobian():
    assert GPU_ATTESTATION is not None
    family=fixture_family()
    theta=np.array([.02,-.04,.01,.07])
    expected=features_numpy(family,theta)
    h=1e-3
    jac=np.column_stack([(-features_numpy(family,theta+2*np.eye(4)[j]*h)+8*features_numpy(family,theta+np.eye(4)[j]*h)
        -8*features_numpy(family,theta-np.eye(4)[j]*h)+features_numpy(family,theta-2*np.eye(4)[j]*h))/(12*h) for j in range(4)])
    for record in GPU_ATTESTATION['devices']:
        assert np.max(np.abs(np.asarray(record['features'])-expected)/(1+np.abs(expected)))<1e-10
        assert np.max(np.abs(np.asarray(record['ratios'])-ratios_numpy(family,theta)))<1e-10
        assert np.max(np.abs(np.asarray(record['jacobian'])-jac)/(1+np.abs(jac)))<1e-10
        assert abs(record['target_value']-features_numpy(family,theta,1)[22])<1e-10
        target_grad=np.array([(-features_numpy(family,theta+2*np.eye(4)[j]*h,1)[22]+8*features_numpy(family,theta+np.eye(4)[j]*h,1)[22]
            -8*features_numpy(family,theta-np.eye(4)[j]*h,1)[22]+features_numpy(family,theta-2*np.eye(4)[j]*h,1)[22])/(12*h) for j in range(4)])
        assert np.max(np.abs(np.asarray(record['target_gradient'])-target_grad)/(1+np.abs(target_grad)))<1e-10


def test_spectral_family_and_fixed_difference_with_hostile_controls():
    ell,m=harmonic_layout(48)
    rng=np.random.default_rng(8217)
    x=rng.normal(size=(2,2,len(ell)))+1j*rng.normal(size=(2,2,len(ell)))*(m>0)
    x[...,ell<30]=0
    planes=build_planes(x,24,shells=[30,35,40],planes_per_shell=2)
    value=apply_angles(x,planes,np.linspace(-.7,.7,6))
    assert invariants(x,value)['passed']
    planes['u'][0]*=1.01;planes['coadd_u'][0]*=1.01
    assert not invariants(x,apply_angles(x,planes,np.full(6,.5)))['passed']


def test_exact_nonclosure_and_redundant_constraint_projection():
    a,b=np.array([1,1,-1,-1]),np.array([1,-1,1,-1])
    assert np.mean(a*a)==np.mean(b*b) and np.mean(a**4)==np.mean(b**4)
    smooth=lambda x:(x+np.roll(x,-1))/2
    assert np.mean(smooth(a)**4)!=np.mean(smooth(b)**4)
    projected,inverse,rank=tangent_reference([[1.,0.],[2.,0.]],np.array([1.,2.]))
    assert rank==1 and np.allclose(projected,[0,2])
    assert matching_bins(np.array([2.]),np.array([2.]),np.ones(1),[0])['matched']
    assert np.array_equal(initial_kicks(24,'fresh')[0],initial_kicks(24,'fresh')[0])


def test_recorded_actual_projected_search_control():
    assert GPU_ATTESTATION is not None
    for device in GPU_ATTESTATION['devices']:
        point=np.asarray(device['nonclosed_control_theta'])
        assert abs(point[0])<.0005 and abs(point[1])>=.05
        assert np.max(np.abs(device['identity_control_gap']))<.001
